public interface INT1
{
	 
	 public double calculateArea();
}
