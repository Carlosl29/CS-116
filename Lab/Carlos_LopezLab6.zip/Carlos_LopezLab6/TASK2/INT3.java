import java.util.*;
public interface INT3
{
	public Vector secreatData ( );
}