import java.util.*;

public class Impl extends Customers implements INT3
{
	public Vector secreatData ( )
	{
		return customerData();
	}
} 